import 'dart:async';
import 'dart:convert';
import 'dart:ui' show DartPluginRegistrant;
import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:flutter_timezone/flutter_timezone.dart';
import 'package:timezone/data/latest_all.dart' as tzdata;
import 'package:timezone/timezone.dart' as tz;
import 'package:shared_preferences/shared_preferences.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const ToDo4ToDayApp());
}

const brown = Color(0xFF5D4037);
const darkBrown = Color(0xFF3E2723);
const yellow = Color(0xFFFFC857);
const cream = Color(0xFFFFF8E8);

String dateKey(DateTime d) => '${d.year.toString().padLeft(4, '0')}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';
String timeKey(TimeOfDay? t) => t == null ? '' : '${t.hour.toString().padLeft(2, '0')}:${t.minute.toString().padLeft(2, '0')}';
TimeOfDay? parseTime(String? s) {
  if (s == null || s.isEmpty || !s.contains(':')) return null;
  final p = s.split(':');
  final h = int.tryParse(p[0]), m = int.tryParse(p[1]);
  if (h == null || m == null || h < 0 || h > 23 || m < 0 || m > 59) return null;
  return TimeOfDay(hour: h, minute: m);
}

const String _taskDoneAction = 'TASK_DONE';
const String _taskContinueAction = 'TASK_CONTINUE';

int _stableNotificationId(String key) {
  var hash = 0x811c9dc5;
  for (final unit in key.codeUnits) {
    hash = ((hash ^ unit) * 0x01000193) & 0x7fffffff;
  }
  return hash;
}

int _endNotificationId(String taskId) => _stableNotificationId('end:$taskId');

NotificationDetails _taskEndNotificationDetails() => const NotificationDetails(
      android: AndroidNotificationDetails(
        'todo4today_task_end_v2',
        'Fin des tâches',
        channelDescription: 'Alerte sonore lorsque la durée prévue d’une tâche est écoulée',
        importance: Importance.max,
        priority: Priority.max,
        category: AndroidNotificationCategory.alarm,
        playSound: true,
        enableVibration: true,
        actions: <AndroidNotificationAction>[
          AndroidNotificationAction(
            _taskDoneAction,
            'Terminé',
            showsUserInterface: false,
            cancelNotification: true,
          ),
          AndroidNotificationAction(
            _taskContinueAction,
            'Continuer (+1 min)',
            showsUserInterface: false,
            cancelNotification: true,
          ),
        ],
      ),
    );

@pragma('vm:entry-point')
Future<void> notificationTapBackground(NotificationResponse response) async {
  WidgetsFlutterBinding.ensureInitialized();
  DartPluginRegistrant.ensureInitialized();
  await _handleBackgroundTaskAction(response);
}

Future<void> _handleBackgroundTaskAction(NotificationResponse response) async {
  final action = response.actionId;
  final taskId = response.payload;
  if (taskId == null || taskId.isEmpty ||
      (action != _taskDoneAction && action != _taskContinueAction)) {
    return;
  }

  final prefs = await SharedPreferences.getInstance();
  await prefs.reload();
  final raw = prefs.getString('tasks');
  if (raw == null) return;

  final items = (jsonDecode(raw) as List)
      .map((item) => Map<String, dynamic>.from(item as Map))
      .toList();
  final index = items.indexWhere((item) => item['id']?.toString() == taskId);
  if (index < 0) return;

  final task = items[index];
  if (task['completed'] == true) return;
  final startedAt = DateTime.tryParse((task['startedAt'] ?? '').toString());
  if (startedAt == null) return;

  final now = DateTime.now();
  final elapsedBefore = (task['elapsedBeforeStart'] as num?)?.toInt() ?? 0;
  final elapsed = elapsedBefore + now.difference(startedAt).inSeconds;

  if (action == _taskDoneAction) {
    task['completed'] = true;
    task['actualSeconds'] = elapsed;
    task['elapsedBeforeStart'] = elapsed;
    task['startedAt'] = null;
    task['completedAt'] = now.toIso8601String();
  } else {
    task['extensionMinutes'] =
        ((task['extensionMinutes'] as num?)?.toInt() ?? 0) + 1;
    task['elapsedBeforeStart'] = elapsed;
    task['startedAt'] = now.toIso8601String();
  }

  await prefs.setString('tasks', jsonEncode(items));

  final notifications = FlutterLocalNotificationsPlugin();
  await notifications.initialize(
    const InitializationSettings(
      android: AndroidInitializationSettings('@mipmap/ic_launcher'),
    ),
    onDidReceiveBackgroundNotificationResponse: notificationTapBackground,
  );
  await notifications.cancel(_endNotificationId(taskId));

  if (action == _taskContinueAction) {
    tzdata.initializeTimeZones();
    final localZone = await FlutterTimezone.getLocalTimezone();
    tz.setLocalLocation(tz.getLocation(localZone.identifier));
    final fireAt = tz.TZDateTime.now(tz.local).add(const Duration(minutes: 1));
    final android = notifications.resolvePlatformSpecificImplementation<
        AndroidFlutterLocalNotificationsPlugin>();
    final exactAllowed =
        await android?.canScheduleExactNotifications() ?? false;
    await notifications.zonedSchedule(
      _endNotificationId(taskId),
      'Temps écoulé',
      'La minute supplémentaire pour « ${task['title'] ?? 'Tâche'} » est terminée.',
      fireAt,
      _taskEndNotificationDetails(),
      androidScheduleMode: exactAllowed
          ? AndroidScheduleMode.exactAllowWhileIdle
          : AndroidScheduleMode.inexactAllowWhileIdle,
      payload: taskId,
    );
  }
}

class TaskItem {
  TaskItem({
    required this.id,
    required this.title,
    this.description = '',
    required this.targetMinutes,
    this.scheduledTime = '',
    this.completed = false,
    this.startedAt,
    this.completedAt,
    this.elapsedBeforeStart = 0,
    this.actualSeconds = 0,
    this.extensionMinutes = 0,
  });

  final String id;
  String title;
  String description;
  int targetMinutes;
  String scheduledTime;
  bool completed;
  DateTime? startedAt;
  DateTime? completedAt;
  int elapsedBeforeStart;
  int actualSeconds;
  int extensionMinutes;

  int elapsedNow() => elapsedBeforeStart +
      (startedAt == null ? 0 : DateTime.now().difference(startedAt!).inSeconds);

  void resetForNewDay() {
    completed = false;
    startedAt = null;
    completedAt = null;
    elapsedBeforeStart = 0;
    actualSeconds = 0;
    extensionMinutes = 0;
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'description': description,
        'targetMinutes': targetMinutes,
        'scheduledTime': scheduledTime,
        'completed': completed,
        'startedAt': startedAt?.toIso8601String(),
        'completedAt': completedAt?.toIso8601String(),
        'elapsedBeforeStart': elapsedBeforeStart,
        'actualSeconds': actualSeconds,
        'extensionMinutes': extensionMinutes,
      };

  factory TaskItem.fromJson(Map<String, dynamic> j) => TaskItem(
        id: j['id']?.toString() ?? DateTime.now().microsecondsSinceEpoch.toString(),
        title: j['title']?.toString() ?? 'Tâche',
        description: j['description']?.toString() ?? '',
        targetMinutes: (j['targetMinutes'] as num?)?.toInt() ?? 30,
        scheduledTime: j['scheduledTime']?.toString() ?? '',
        completed: j['completed'] == true,
        startedAt: j['startedAt'] == null ? null : DateTime.tryParse(j['startedAt'].toString()),
        completedAt: j['completedAt'] == null ? null : DateTime.tryParse(j['completedAt'].toString()),
        elapsedBeforeStart: (j['elapsedBeforeStart'] as num?)?.toInt() ?? 0,
        actualSeconds: (j['actualSeconds'] as num?)?.toInt() ?? 0,
        extensionMinutes: (j['extensionMinutes'] as num?)?.toInt() ?? 0,
      );
}

class ToDo4ToDayApp extends StatelessWidget {
  const ToDo4ToDayApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'ToDo4ToDay by RTNA',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          useMaterial3: true,
          scaffoldBackgroundColor: cream,
          colorScheme: ColorScheme.fromSeed(seedColor: brown, primary: brown, secondary: yellow),
          appBarTheme: const AppBarTheme(backgroundColor: brown, foregroundColor: Colors.white),
          floatingActionButtonTheme: const FloatingActionButtonThemeData(backgroundColor: yellow, foregroundColor: darkBrown),
        ),
        home: const HomePage(),
      );
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with WidgetsBindingObserver {
  final List<TaskItem> tasks = [];
  final List<Map<String, dynamic>> dailyHistory = [];
  Timer? ticker;
  final FlutterLocalNotificationsPlugin _notifications =
      FlutterLocalNotificationsPlugin();
  bool _notificationsReady = false;
  bool _exactAlarmsAllowed = false;
  int tab = 0;
  bool loading = true;
  String currentDay = dateKey(DateTime.now());

  int _notificationId(String taskId) {
    // Identifiant déterministe, stable entre les ouvertures de l'application.
    var hash = 0x811c9dc5;
    for (final unit in taskId.codeUnits) {
      hash = ((hash ^ unit) * 0x01000193) & 0x7fffffff;
    }
    return hash;
  }

  Future<void> _initializeNotifications() async {
    if (_notificationsReady) return;

    const androidSettings = AndroidInitializationSettings('@mipmap/ic_launcher');
    await _notifications.initialize(
      const InitializationSettings(android: androidSettings),
      onDidReceiveNotificationResponse: _handleNotificationResponse,
      onDidReceiveBackgroundNotificationResponse: notificationTapBackground,
    );

    final android = _notifications.resolvePlatformSpecificImplementation<
        AndroidFlutterLocalNotificationsPlugin>();

    // Android 13+ demande l'autorisation d'afficher les notifications.
    await android?.requestNotificationsPermission();

    // Les alarmes exactes permettent de viser précisément la minute choisie.
    _exactAlarmsAllowed =
        await android?.canScheduleExactNotifications() ?? false;
    if (!_exactAlarmsAllowed) {
      await android?.requestExactAlarmsPermission();
      _exactAlarmsAllowed =
          await android?.canScheduleExactNotifications() ?? false;
    }

    tzdata.initializeTimeZones();
    final localZone = await FlutterTimezone.getLocalTimezone();
    tz.setLocalLocation(tz.getLocation(localZone.identifier));

    _notificationsReady = true;
  }

  void _handleNotificationResponse(NotificationResponse response) {
    if (response.actionId == _taskDoneAction ||
        response.actionId == _taskContinueAction) {
      unawaited(_applyTaskEndAction(response));
    }
  }

  Future<void> _applyTaskEndAction(NotificationResponse response) async {
    final taskId = response.payload;
    if (taskId == null) return;
    TaskItem? task;
    for (final candidate in tasks) {
      if (candidate.id == taskId) {
        task = candidate;
        break;
      }
    }
    if (task == null || task.completed || task.startedAt == null) return;

    final now = DateTime.now();
    final elapsed = task.elapsedNow();
    if (response.actionId == _taskDoneAction) {
      task.actualSeconds = elapsed;
      task.elapsedBeforeStart = elapsed;
      task.startedAt = null;
      task.completed = true;
      task.completedAt = now;
      await _cancelTaskEndNotification(task.id);
    } else if (response.actionId == _taskContinueAction) {
      task.elapsedBeforeStart = elapsed;
      task.extensionMinutes += 1;
      task.startedAt = now;
      await _scheduleTaskEndNotification(task);
    }
    await saveTasks();
    if (mounted) setState(() {});
  }

  Future<void> _cancelTaskEndNotification(String taskId) async {
    if (!_notificationsReady) return;
    await _notifications.cancel(_endNotificationId(taskId));
  }

  Future<void> _scheduleTaskEndNotification(TaskItem task) async {
    if (!_notificationsReady) return;
    final id = _endNotificationId(task.id);
    await _notifications.cancel(id);
    if (task.completed || task.startedAt == null) return;

    final limitSeconds = (task.targetMinutes + task.extensionMinutes) * 60;
    final remainingSeconds = limitSeconds - task.elapsedNow();
    final delay = Duration(seconds: remainingSeconds > 0 ? remainingSeconds : 1);
    final fireAt = tz.TZDateTime.now(tz.local).add(delay);

    await _notifications.zonedSchedule(
      id,
      'Temps écoulé',
      'La durée prévue pour « ${task.title} » est terminée.',
      fireAt,
      _taskEndNotificationDetails(),
      androidScheduleMode: _exactAlarmsAllowed
          ? AndroidScheduleMode.exactAllowWhileIdle
          : AndroidScheduleMode.inexactAllowWhileIdle,
      payload: task.id,
    );
  }

  Future<void> _scheduleTaskReminder(TaskItem task) async {
    if (!_notificationsReady) return;

    final id = _notificationId(task.id);
    await _notifications.cancel(id);

    final parts = task.scheduledTime.split(':');
    if (parts.length != 2) return;
    final hour = int.tryParse(parts[0]);
    final minute = int.tryParse(parts[1]);
    if (hour == null || minute == null ||
        hour < 0 || hour > 23 || minute < 0 || minute > 59) {
      return;
    }

    final now = tz.TZDateTime.now(tz.local);
    var taskTime = tz.TZDateTime(
      tz.local, now.year, now.month, now.day, hour, minute,
    );
    var reminderTime = taskTime.subtract(const Duration(minutes: 1));

    // Si l'heure est déjà passée aujourd'hui, ou si la tâche est terminée,
    // le prochain rappel sera celui du lendemain.
    if (!reminderTime.isAfter(now) || task.completed) {
      taskTime = taskTime.add(const Duration(days: 1));
      reminderTime = taskTime.subtract(const Duration(minutes: 1));
    }

    await _notifications.zonedSchedule(
      id,
      'Rappel de tâche',
      'Dans 1 minute : ${task.title}',
      reminderTime,
      const NotificationDetails(
        android: AndroidNotificationDetails(
          'todo4today_task_reminders',
          'Rappels des tâches',
          channelDescription: 'Rappel une minute avant chaque tâche prévue',
          importance: Importance.max,
          priority: Priority.high,
          playSound: true,
          enableVibration: true,
        ),
      ),
      androidScheduleMode: _exactAlarmsAllowed
          ? AndroidScheduleMode.exactAllowWhileIdle
          : AndroidScheduleMode.inexactAllowWhileIdle,
      matchDateTimeComponents: DateTimeComponents.time,
    );
  }

  Future<void> _syncTaskReminders() async {
    if (!_notificationsReady) return;

    // Ne conserver que les notifications réellement manquantes. cancelAll()
    // supprimait aussi les rappels imminents, puis les reprogrammait parfois
    // au lendemain si leur heure venait juste de passer.
    final pending = await _notifications.pendingNotificationRequests();
    final pendingIds = pending.map((request) => request.id).toSet();

    for (final task in tasks) {
      final reminderId = _notificationId(task.id);
      final endId = _endNotificationId(task.id);

      if (task.scheduledTime.isNotEmpty && !pendingIds.contains(reminderId)) {
        await _scheduleTaskReminder(task);
      }

      if (!task.completed && task.startedAt != null) {
        if (!pendingIds.contains(endId)) {
          await _scheduleTaskEndNotification(task);
        }
      } else if (pendingIds.contains(endId)) {
        await _notifications.cancel(endId);
      }
    }
  }


  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    loadTasks();
    ticker = Timer.periodic(const Duration(seconds: 1), (_) {
      _ensureCurrentDay();
      if (mounted) setState(() {});
    });
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      unawaited(_refreshTasksFromStorage());
    }
  }

  @override
  void dispose() {
    ticker?.cancel();
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  Future<void> _refreshTasksFromStorage() async {
    // Une action de notification peut encore être en cours dans son isolate
    // lorsque l'application revient au premier plan. Laisser le temps à
    // SharedPreferences de recevoir l'écriture avant de relire l'état.
    await Future<void>.delayed(const Duration(milliseconds: 700));
    final p = await SharedPreferences.getInstance();
    await p.reload();
    final raw = p.getString('tasks');
    if (raw != null) {
      try {
        tasks
          ..clear()
          ..addAll((jsonDecode(raw) as List).map(
            (e) => TaskItem.fromJson(Map<String, dynamic>.from(e)),
          ));
      } catch (e) {
        debugPrint('Actualisation des tâches impossible : $e');
      }
    }
    await _ensureCurrentDay();
    // Ne pas reconstruire les alarmes à chaque retour au premier plan :
    // cela peut annuler un rappel qui doit sonner dans quelques secondes.
    if (mounted) setState(() {});
  }

  Future<void> loadTasks() async {
    final p = await SharedPreferences.getInstance();
    final raw = p.getString('tasks');
    final historyRaw = p.getString('dailyHistory');
    currentDay = p.getString('currentDay') ?? dateKey(DateTime.now());
    if (raw != null) {
      try {
        tasks.addAll((jsonDecode(raw) as List).map((e) => TaskItem.fromJson(Map<String, dynamic>.from(e))));
      } catch (e) { debugPrint('Lecture des tâches impossible: $e'); }
    }
    if (historyRaw != null) {
      try {
        dailyHistory.addAll((jsonDecode(historyRaw) as List).map((e) => Map<String, dynamic>.from(e)));
      } catch (e) { debugPrint('Lecture de l’historique impossible: $e'); }
    }
    await _ensureCurrentDay();
    try {
      await _initializeNotifications();
      await _syncTaskReminders();
    } catch (e) {
      debugPrint('Initialisation des rappels impossible : $e');
    }
    if (mounted) setState(() => loading = false);
  }

  Future<void> saveTasks() async {
    final p = await SharedPreferences.getInstance();
    await p.setString('tasks', jsonEncode(tasks.map((e) => e.toJson()).toList()));
    await p.setString('dailyHistory', jsonEncode(dailyHistory));
    await p.setString('currentDay', currentDay);
  }

  Future<void> _ensureCurrentDay() async {
    final today = dateKey(DateTime.now());
    if (today == currentDay) return;
    if (tasks.isNotEmpty) {
      dailyHistory.add({
        'date': currentDay,
        'tasks': tasks.map((t) => {
          'id': t.id,
          'title': t.title,
          'scheduledTime': t.scheduledTime,
          'targetMinutes': t.targetMinutes,
          'completed': t.completed,
          'actualSeconds': t.completed ? t.actualSeconds : t.elapsedNow(),
          'completedAt': t.completedAt?.toIso8601String(),
        }).toList(),
      });
      if (dailyHistory.length > 90) dailyHistory.removeRange(0, dailyHistory.length - 90);
    }
    for (final t in tasks) t.resetForNewDay();
    currentDay = today;
    await saveTasks();
    if (_notificationsReady) await _syncTaskReminders();
    if (mounted) setState(() {});
  }

  Map<String, dynamic>? _previousRecord(String taskId) {
    for (final day in dailyHistory.reversed) {
      final list = (day['tasks'] as List?) ?? [];
      for (final raw in list) {
        final record = Map<String, dynamic>.from(raw as Map);
        if (record['id']?.toString() == taskId) return {'date': day['date'], ...record};
      }
    }
    return null;
  }

  Future<void> addOrEdit({TaskItem? task}) async {
    final title = TextEditingController(text: task?.title ?? '');
    final desc = TextEditingController(text: task?.description ?? '');
    final mins = TextEditingController(text: '${task?.targetMinutes ?? 30}');
    TimeOfDay? chosenTime = parseTime(task?.scheduledTime);
    final result = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(builder: (ctx, refreshDialog) => AlertDialog(
        title: Text(task == null ? 'Nouvelle tâche' : 'Modifier la tâche'),
        content: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
          TextField(controller: title, autofocus: true, decoration: const InputDecoration(labelText: 'Nom de la tâche')),
          TextField(controller: desc, decoration: const InputDecoration(labelText: 'Description'), maxLines: 2),
          TextField(controller: mins, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Durée prévue (minutes)')),
          const SizedBox(height: 10),
          Align(alignment: Alignment.centerLeft, child: Text('Heure prévue', style: TextStyle(color: Colors.brown.shade700))),
          OutlinedButton.icon(
            onPressed: () async {
              final picked = await showTimePicker(context: ctx, initialTime: chosenTime ?? TimeOfDay.now());
              if (picked != null) refreshDialog(() => chosenTime = picked);
            },
            icon: const Icon(Icons.schedule),
            label: Text(chosenTime == null ? 'Choisir une heure' : chosenTime!.format(ctx)),
          ),
        ])),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Annuler')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Enregistrer')),
        ],
      )),
    );
    if (result != true || title.text.trim().isEmpty) return;
    final n = (int.tryParse(mins.text.trim()) ?? 30).clamp(1, 1440);
    if (task == null) {
      tasks.add(TaskItem(
        id: DateTime.now().microsecondsSinceEpoch.toString(),
        title: title.text.trim(),
        description: desc.text.trim(),
        targetMinutes: n,
        scheduledTime: timeKey(chosenTime),
      ));
    } else {
      task.title = title.text.trim();
      task.description = desc.text.trim();
      task.targetMinutes = n;
      task.scheduledTime = timeKey(chosenTime);
    }
    final savedTask = task ?? tasks.last;
    await saveTasks();
    await _scheduleTaskReminder(savedTask);
    if (savedTask.startedAt != null && !savedTask.completed) {
      await _scheduleTaskEndNotification(savedTask);
    }
    if (mounted) setState(() {});
  }

  Future<void> toggleTimer(TaskItem t) async {
    if (t.completed) return;
    if (t.startedAt == null) {
      t.startedAt = DateTime.now();
    } else {
      t.elapsedBeforeStart = t.elapsedNow();
      t.startedAt = null;
    }
    await saveTasks();
    if (t.startedAt == null) {
      await _cancelTaskEndNotification(t.id);
    } else {
      await _scheduleTaskEndNotification(t);
    }
    setState(() {});
  }

  Future<void> finish(TaskItem t) async {
    t.actualSeconds = t.elapsedNow();
    t.elapsedBeforeStart = t.actualSeconds;
    t.startedAt = null;
    t.completed = true;
    t.completedAt = DateTime.now();
    await saveTasks();
    await _cancelTaskEndNotification(t.id);
    await _scheduleTaskReminder(t);
    setState(() {});
  }

  Future<void> delete(TaskItem t) async {
    final ok = await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(
      title: const Text('Supprimer cette tâche ?'),
      content: Text('« ${t.title} » sera supprimée des tâches quotidiennes. Son historique passé sera conservé.'),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Annuler')),
        FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Supprimer')),
      ],
    ));
    if (ok == true) {
      if (_notificationsReady) {
        await _notifications.cancel(_notificationId(t.id));
        await _cancelTaskEndNotification(t.id);
      }
      tasks.removeWhere((x) => x.id == t.id);
      await saveTasks();
      setState(() {});
    }
  }

  String duration(int s) {
    final h = s ~/ 3600, m = (s % 3600) ~/ 60, sec = s % 60;
    return h > 0 ? '${h}h ${m.toString().padLeft(2, '0')}m' : '${m}m ${sec.toString().padLeft(2, '0')}s';
  }

  String clockLabel(DateTime? d) => d == null ? '—' : '${d.hour.toString().padLeft(2, '0')}:${d.minute.toString().padLeft(2, '0')}';

  @override
  Widget build(BuildContext context) {
    final done = tasks.where((t) => t.completed).length;
    final total = tasks.length;
    return Scaffold(
      appBar: AppBar(title: Row(children: [
        Image.asset('assets/app_icon.png', width: 38, height: 38),
        const SizedBox(width: 9),
        const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('ToDo4ToDay', style: TextStyle(fontWeight: FontWeight.bold)),
          Text('by RTNA', style: TextStyle(fontSize: 11, color: yellow)),
        ]),
      ]), actions: [IconButton(onPressed: () => showAboutDialog(context: context, applicationName: 'ToDo4ToDay by RTNA', applicationVersion: '1.5.0', children: const [Text('Ton assistant quotidien, utilisable hors connexion.')]), icon: const Icon(Icons.info_outline))]),
      body: loading ? const Center(child: CircularProgressIndicator()) : tab == 0 ? _dashboard(done, total) : _stats(done, total),
      floatingActionButton: tab == 0 ? FloatingActionButton.extended(onPressed: () => addOrEdit(), icon: const Icon(Icons.add), label: const Text('Ajouter')) : null,
      bottomNavigationBar: NavigationBar(selectedIndex: tab, onDestinationSelected: (v) => setState(() => tab = v), destinations: const [
        NavigationDestination(icon: Icon(Icons.checklist), label: 'Mes tâches'),
        NavigationDestination(icon: Icon(Icons.bar_chart), label: 'Bilan'),
      ]),
    );
  }

  Widget _dashboard(int done, int total) {
    final active = tasks.where((t) => !t.completed).length;
    final sorted = [...tasks]..sort((a, b) {
      if (a.scheduledTime.isEmpty && b.scheduledTime.isEmpty) return 0;
      if (a.scheduledTime.isEmpty) return 1;
      if (b.scheduledTime.isEmpty) return -1;
      return a.scheduledTime.compareTo(b.scheduledTime);
    });
    return ListView(padding: const EdgeInsets.all(16), children: [
      Container(padding: const EdgeInsets.all(18), decoration: BoxDecoration(color: brown, borderRadius: BorderRadius.circular(20)), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('Aujourd’hui, avance à ton rythme.', style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
        const SizedBox(height: 5),
        Text('Date : $currentDay', style: const TextStyle(color: Colors.white70, fontSize: 12)),
        const SizedBox(height: 12),
        Row(children: [
          Expanded(child: _metric('$total', 'Tâches')),
          Expanded(child: _metric('$done', 'Terminées')),
          Expanded(child: _metric('${total == 0 ? 0 : (done * 100 / total).round()}%', 'Progression')),
        ]),
        const SizedBox(height: 10),
        ClipRRect(borderRadius: BorderRadius.circular(10), child: LinearProgressIndicator(value: total == 0 ? 0 : done / total, minHeight: 8, backgroundColor: Colors.white24, color: yellow)),
      ])),
      const SizedBox(height: 20),
      Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [const Text('Mes tâches', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: darkBrown)), Text('$active en cours', style: const TextStyle(color: brown))]),
      const SizedBox(height: 8),
      if (tasks.isEmpty) Container(padding: const EdgeInsets.all(28), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16)), child: const Column(children: [Icon(Icons.event_note, size: 42, color: brown), SizedBox(height: 8), Text('Aucune tâche pour le moment'), Text('Appuie sur Ajouter pour commencer.', style: TextStyle(color: Colors.black54))]))
      else ...sorted.map(_taskCard),
    ]);
  }

  Widget _metric(String value, String label) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(value, style: const TextStyle(color: yellow, fontSize: 22, fontWeight: FontWeight.bold)), Text(label, style: const TextStyle(color: Colors.white70, fontSize: 12))]);

  Widget _taskCard(TaskItem t) {
    final elapsed = t.completed ? t.actualSeconds : t.elapsedNow();
    final running = t.startedAt != null;
    final previous = _previousRecord(t.id);
    return Card(color: Colors.white, margin: const EdgeInsets.only(bottom: 10), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)), child: Padding(padding: const EdgeInsets.all(14), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [
        Expanded(child: Text(t.title, style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, decoration: t.completed ? TextDecoration.lineThrough : null, color: darkBrown))),
        PopupMenuButton<String>(onSelected: (v) { if (v == 'edit') addOrEdit(task: t); if (v == 'delete') delete(t); }, itemBuilder: (_) => const [PopupMenuItem(value: 'edit', child: Text('Modifier')), PopupMenuItem(value: 'delete', child: Text('Supprimer'))]),
      ]),
      if (t.description.isNotEmpty) Text(t.description, style: const TextStyle(color: Colors.black54)),
      const SizedBox(height: 8),
      Row(children: [const Icon(Icons.schedule, size: 16, color: brown), const SizedBox(width: 4), Text('Heure : ${t.scheduledTime.isEmpty ? 'non définie' : t.scheduledTime}'), const Spacer(), const Icon(Icons.flag_outlined, size: 16, color: brown), const SizedBox(width: 4), Text('${t.targetMinutes} min prévues')]),
      const SizedBox(height: 5),
      Row(children: [const Icon(Icons.timer_outlined, size: 16, color: brown), const SizedBox(width: 4), Text('Écoulé : ${duration(elapsed)}')]),
      if (previous != null && t.completed && previous['completed'] == true && previous['completedAt'] != null && t.completedAt != null) ...[
        const SizedBox(height: 6),
        _comparisonLine(t.completedAt!, DateTime.tryParse(previous['completedAt'].toString()), 'Heure de fin vs ${previous['date']}'),
      ],
      const SizedBox(height: 10),
      if (!t.completed) Row(children: [
        Expanded(child: OutlinedButton.icon(onPressed: () => toggleTimer(t), icon: Icon(running ? Icons.pause : Icons.play_arrow), label: Text(running ? 'Pause' : 'Démarrer'))),
        const SizedBox(width: 8),
        Expanded(child: FilledButton.icon(onPressed: () => finish(t), icon: const Icon(Icons.check), label: const Text('Terminer'))),
      ]) else const Row(children: [Icon(Icons.check_circle, color: Colors.green), SizedBox(width: 6), Text('Terminée', style: TextStyle(color: Colors.green, fontWeight: FontWeight.bold))]),
    ])));
  }

  Widget _comparisonLine(DateTime current, DateTime? previous, String label) {
    if (previous == null) return const SizedBox.shrink();
    final currentMinute = current.hour * 60 + current.minute;
    final previousMinute = previous.hour * 60 + previous.minute;
    final diff = currentMinute - previousMinute;
    final text = diff == 0 ? 'Même heure de fin qu’hier' : diff < 0 ? 'Terminée ${-diff} min plus tôt qu’auparavant' : 'Terminée $diff min plus tard qu’auparavant';
    final color = diff <= 0 ? Colors.green.shade700 : Colors.deepOrange;
    return Row(children: [Icon(diff <= 0 ? Icons.trending_up : Icons.trending_down, size: 16, color: color), const SizedBox(width: 4), Expanded(child: Text('$text (${clockLabel(previous)} → ${clockLabel(current)})', style: TextStyle(fontSize: 12, color: color)))]);
  }

  Widget _stats(int done, int total) {
    final seconds = tasks.fold<int>(0, (sum, t) => sum + (t.completed ? t.actualSeconds : t.elapsedNow()));
    final planned = tasks.fold<int>(0, (sum, t) => sum + t.targetMinutes * 60);
    final previousDay = dailyHistory.isEmpty ? null : dailyHistory.last;
    final previousTasks = previousDay == null ? <Map<String, dynamic>>[] : ((previousDay['tasks'] as List?) ?? []).map((e) => Map<String, dynamic>.from(e as Map)).toList();
    return ListView(padding: const EdgeInsets.all(16), children: [
      const Text('Mon bilan du jour', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: darkBrown)),
      const SizedBox(height: 14),
      _statTile(Icons.task_alt, 'Tâches terminées', '$done / $total'),
      _statTile(Icons.timer, 'Temps réellement consacré', duration(seconds)),
      _statTile(Icons.flag, 'Temps prévu cumulé', duration(planned)),
      _statTile(Icons.insights, 'Progression', '${total == 0 ? 0 : (done * 100 / total).round()} %'),
      const SizedBox(height: 16),
      const Text('Comparaison avec la journée précédente', style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold, color: darkBrown)),
      const SizedBox(height: 6),
      if (previousDay == null) const Text('Les comparaisons apparaîtront après une première journée enregistrée.', style: TextStyle(color: Colors.black54))
      else Text('Comparaison avec le ${previousDay['date']}', style: const TextStyle(color: Colors.black54)),
      const SizedBox(height: 8),
      ...tasks.map((t) {
        final old = previousTasks.where((e) => e['id']?.toString() == t.id).cast<Map<String, dynamic>?>().firstWhere((e) => e != null, orElse: () => null);
        final actual = t.completed ? t.actualSeconds : t.elapsedNow();
        final max = (t.targetMinutes * 60).clamp(1, 1000000000);
        String comparison = 'Pas encore de résultat précédent';
        Color comparisonColor = Colors.black54;
        if (old != null && old['completed'] == true && t.completed) {
          final oldSeconds = (old['actualSeconds'] as num?)?.toInt() ?? 0;
          final diff = actual - oldSeconds;
          comparison = diff == 0 ? 'Même durée que la fois précédente' : diff < 0 ? 'Durée réduite de ${duration(-diff)}' : 'Durée augmentée de ${duration(diff)}';
          comparisonColor = diff <= 0 ? Colors.green.shade700 : Colors.deepOrange;
          final oldFinish = old['completedAt'] == null ? null : DateTime.tryParse(old['completedAt'].toString());
          if (oldFinish != null && t.completedAt != null) {
            final delta = (t.completedAt!.hour * 60 + t.completedAt!.minute) - (oldFinish.hour * 60 + oldFinish.minute);
            comparison += delta == 0 ? ' • fin à la même heure' : delta < 0 ? ' • fin ${-delta} min plus tôt' : ' • fin $delta min plus tard';
          }
        }
        return Padding(padding: const EdgeInsets.only(bottom: 14), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(t.title, style: const TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 4),
          ClipRRect(borderRadius: BorderRadius.circular(8), child: LinearProgressIndicator(value: (actual / max).clamp(0.0, 1.0), minHeight: 9, color: actual > max ? Colors.deepOrange : brown, backgroundColor: Colors.brown.shade100)),
          Text('${duration(actual)} / ${t.targetMinutes} min prévues', style: const TextStyle(fontSize: 12, color: Colors.black54)),
          Text(comparison, style: TextStyle(fontSize: 12, color: comparisonColor)),
        ]));
      }),
      const SizedBox(height: 10),
      const Text('Les résultats quotidiens sont enregistrés sur cet appareil. Les tâches se réinitialisent automatiquement au changement de date.', style: TextStyle(color: Colors.black54)),
    ]);
  }

  Widget _statTile(IconData icon, String label, String value) => Card(color: Colors.white, child: ListTile(leading: Icon(icon, color: brown), title: Text(label), trailing: Text(value, style: const TextStyle(fontWeight: FontWeight.bold, color: darkBrown))));
}
